package com.cg.employee.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.employee.beans.Employee;
import com.cg.employee.dao.EmployeeDAO;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;

@Component("employeeServices")
public class EmployeeServices implements EmployeeImpl
{
	@Autowired
	EmployeeDAO employeeDAO;

	@Override
	public Employee acceptEmployeeDetails(Employee employee) {
		employee = employeeDAO.save(employee);
		return employee;
	}

	@Override
	public Employee getEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException {
		Employee employee = employeeDAO.findById(empId).orElseThrow(()->new EmployeeDetailsNotFoundException("Sorry Employee Details Not Found!"));
		return employee;
	}

	@Override
	public List<Employee> getAllEmployeeDetails() {
		return employeeDAO.findAll();
	}

	@Override
	public boolean deleteEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException {
		Employee employee = getEmployeeDetails(empId);
		employeeDAO.delete(employee);
		return true;
	}

	@Override
	public Employee updateEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException {
		Employee employee = getEmployeeDetails(empId);
		employee.setFirstName(employee.getFirstName());
		employee.setLastName(employee.getLastName());
		employee.setEmail(employee.getEmail());
		employeeDAO.save(employee);
		return employee;
	}

}
