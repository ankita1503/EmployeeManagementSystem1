package com.cg.employee.services;

import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;

public interface EmployeeImpl 
{

	public Employee acceptEmployeeDetails(Employee employee);
	
	public Employee getEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException;
	
	public List<Employee> getAllEmployeeDetails();
	
	public boolean deleteEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException;
	
	public Employee updateEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException;
} 
